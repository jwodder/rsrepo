[![Project Status: Active – The project has reached a stable, usable state and is being actively developed.](https://www.repostatus.org/badges/latest/active.svg)](https://www.repostatus.org/#active)
[![CI Status](https://github.com/jwodder-test/fibonacci/actions/workflows/test.yml/badge.svg)](https://github.com/jwodder-test/fibonacci/actions/workflows/test.yml)
[![codecov.io](https://codecov.io/gh/jwodder-test/fibonacci/branch/main/graph/badge.svg)](https://codecov.io/gh/jwodder-test/fibonacci)
[![MIT License](https://img.shields.io/github/license/jwodder-test/fibonacci.svg)](https://opensource.org/licenses/MIT)

This is a Rust program for computing elements of the Fibonacci sequence.
