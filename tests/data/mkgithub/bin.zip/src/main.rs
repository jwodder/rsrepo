use std::process::ExitCode;

fn main() -> ExitCode {
    match std::env::args().nth(1) {
        Some(s) => match s.parse::<usize>() {
            Ok(n) => match fibonacci(n) {
                Some(fib) => {
                    println!("{fib}");
                    ExitCode::SUCCESS
                }
                None => {
                    eprintln!("OUT OF RANGE");
                    ExitCode::FAILURE
                }
            },
            Err(_) => {
                eprintln!("invalid argument");
                ExitCode::FAILURE
            }
        },
        None => {
            let mut first = true;
            for n in 1..=12 {
                if !std::mem::replace(&mut first, false) {
                    print!(" ");
                }
                print!("{}", fibonacci(n).unwrap());
            }
            println!();
            ExitCode::SUCCESS
        }
    }
}

fn fibonacci(n: usize) -> Option<usize> {
    let (mut a, mut b) = (1usize, 0usize);
    for _ in 0..n {
        (a, b) = (b, a.checked_add(b)?);
    }
    Some(b)
}

#[cfg(test)]
mod tests {
    use super::*;
    use rstest::rstest;

    #[rstest]
    #[case(0, 0)]
    #[case(1, 1)]
    #[case(2, 1)]
    #[case(3, 2)]
    #[case(4, 3)]
    #[case(5, 5)]
    #[case(6, 8)]
    #[case(7, 13)]
    #[case(8, 21)]
    #[case(9, 34)]
    #[case(10, 55)]
    #[case(11, 89)]
    #[case(12, 144)]
    fn test_fibonacci(#[case] n: usize, #[case] fib: usize) {
        assert_eq!(fibonacci(n), Some(fib));
    }
}
