use fibonacci::fibonacci;
use std::process::ExitCode;

fn main() -> ExitCode {
    match std::env::args().nth(1) {
        Some(s) => match s.parse::<usize>() {
            Ok(n) => match fibonacci(n) {
                Some(fib) => {
                    println!("{fib}");
                    ExitCode::SUCCESS
                }
                None => {
                    eprintln!("OUT OF RANGE");
                    ExitCode::FAILURE
                }
            }
            Err(_) => {
                eprintln!("invalid argument");
                ExitCode::FAILURE
            }
        }
        None => {
            let mut first = true;
            for n in 1..=12 {
                if !std::mem::replace(&mut first, false) {
                    print!(" ");
                }
                print!("{}", fibonacci(n).unwrap());
            }
            println!();
            ExitCode::SUCCESS
        }
    }
}
