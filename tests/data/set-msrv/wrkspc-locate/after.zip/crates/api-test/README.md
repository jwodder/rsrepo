[![Project Status: Concept – Minimal or no implementation has been done yet, or the repository is only intended to be a limited example, demo, or proof-of-concept.](https://www.repostatus.org/badges/latest/concept.svg)](https://www.repostatus.org/#concept)
[![Minimum Supported Rust Version](https://img.shields.io/badge/MSRV-1.75-orange)](https://www.rust-lang.org)
[![MIT License](https://img.shields.io/github/license/jwodder/sudoku.svg)](https://opensource.org/licenses/MIT)

This is a utility program for testing the `sudoku` library by fetching a Sudoku
puzzle from https://www.youdosudoku.com and checking that the library produces
the correct solution.

Usage
=====

    cargo run -- [<difficulty>]

`<difficulty>` is the difficulty of the puzzle to fetch; it can be "easy",
"medium", or "hard" (all case-insensitive).
