v0.2.0 (in development)
-----------------------
- Added `serde` support

- Fooed a bar


v0.1.0 (2023-01-01)
-------------------
Initial release
