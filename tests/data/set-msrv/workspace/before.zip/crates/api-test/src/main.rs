use serde::{Deserialize, Serialize};
use std::process::ExitCode;
use sudoku::{Puzzle, Solution, TryIntoPuzzleError};
use thiserror::Error;

fn main() -> anyhow::Result<ExitCode> {
    let difficulty = match std::env::args()
        .nth(1)
        .map(|s| s.to_ascii_lowercase())
        .as_deref()
    {
        Some("easy") => Difficulty::Easy,
        Some("medium") | None => Difficulty::Medium,
        Some("hard") => Difficulty::Hard,
        Some(_) => anyhow::bail!("invalid difficulty specified"),
    };
    let ApiPuzzle { puzzle, solution } = get_api_puzzle(difficulty)?;
    println!("Puzzle:");
    println!("{:#}\n", puzzle);
    match puzzle.solve() {
        Some(s) if s == solution => {
            println!("Solution:");
            println!("{:#}", s);
            Ok(ExitCode::SUCCESS)
        }
        Some(s) => {
            println!("Calculated solution:");
            println!("{:#}\n", s);
            println!("Expected solution:");
            println!("{:#}", solution);
            Ok(ExitCode::FAILURE)
        }
        None => {
            println!("Failed to compute a solution!\n");
            println!("Expected solution:");
            println!("{:#}", solution);
            Ok(ExitCode::FAILURE)
        }
    }
}

#[derive(Copy, Clone, Debug, Eq, PartialEq, Serialize)]
#[serde(rename_all = "lowercase")]
enum Difficulty {
    Easy,
    Medium,
    Hard,
}

fn get_api_puzzle(difficulty: Difficulty) -> anyhow::Result<ApiPuzzle> {
    ureq::post("https://www.youdosudoku.com/api")
        .send_json(ApiPayload::from(difficulty))?
        .into_json()
        .map_err(Into::into)
}

#[derive(Copy, Clone, Debug, Eq, PartialEq, Serialize)]
struct ApiPayload {
    difficulty: Difficulty,
    solution: bool,
    array: bool,
}

impl From<Difficulty> for ApiPayload {
    fn from(difficulty: Difficulty) -> ApiPayload {
        ApiPayload {
            difficulty,
            solution: true,
            array: true,
        }
    }
}

#[derive(Copy, Clone, Debug, Deserialize, Eq, PartialEq)]
#[serde(try_from = "RawApiPuzzle")]
struct ApiPuzzle {
    puzzle: Puzzle,
    solution: Solution,
}

impl TryFrom<RawApiPuzzle> for ApiPuzzle {
    type Error = ApiPuzzleError;

    fn try_from(value: RawApiPuzzle) -> Result<ApiPuzzle, ApiPuzzleError> {
        let puzzle = Puzzle::try_from(char_grid_to_u8_grid(value.puzzle)?)?;
        let solution = Solution::from(char_grid_to_u8_grid(value.solution)?);
        Ok(ApiPuzzle { puzzle, solution })
    }
}

#[derive(Copy, Clone, Debug, Deserialize, Eq, PartialEq)]
struct RawApiPuzzle {
    puzzle: [[char; 9]; 9],
    solution: [[char; 9]; 9],
}

fn char_grid_to_u8_grid(grid: [[char; 9]; 9]) -> Result<[[u8; 9]; 9], GridError> {
    let mut outgrid = Vec::with_capacity(9);
    for row in grid {
        let mut outrow = Vec::with_capacity(9);
        for c in row {
            match c.to_digit(10).and_then(|d| u8::try_from(d).ok()) {
                Some(d) => outrow.push(d),
                None => return Err(GridError(c)),
            }
        }
        outgrid.push(<[u8; 9]>::try_from(outrow).unwrap());
    }
    Ok(outgrid
        .try_into()
        .expect("9x9 Vec should convert to 9x9 array"))
}

#[derive(Clone, Copy, Debug, Eq, Error, PartialEq)]
enum ApiPuzzleError {
    #[error(transparent)]
    Puzzle(#[from] TryIntoPuzzleError),
    #[error(transparent)]
    Grid(#[from] GridError),
}

#[derive(Clone, Copy, Debug, Eq, Error, PartialEq)]
#[error("character {0:?} is not a digit")]
struct GridError(char);
