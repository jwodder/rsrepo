v0.2.0 (in development)
-----------------------
- Added `serde` support
- Increased MSRV to 1.75
- Fooed a bar

v0.1.0 (2023-01-01)
-------------------
Initial release
