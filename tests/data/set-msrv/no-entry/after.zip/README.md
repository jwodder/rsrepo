[![Project Status: WIP – Initial development is in progress, but there has not yet been a stable, usable release suitable for the public.](https://www.repostatus.org/badges/latest/wip.svg)](https://www.repostatus.org/#wip)
[![CI Status](https://github.com/rs.test/foobar/actions/workflows/test.yml/badge.svg)](https://github.com/rs.test/foobar/actions/workflows/test.yml)
[![codecov.io](https://codecov.io/gh/rs.test/foobar/branch/master/graph/badge.svg)](https://codecov.io/gh/rs.test/foobar)
[![Minimum Supported Rust Version](https://img.shields.io/badge/MSRV-1.75-orange)](https://www.rust-lang.org)
[![MIT License](https://img.shields.io/github/license/rs.test/foobar.svg)](https://opensource.org/licenses/MIT)

[GitHub](https://github.com/rs.test/foobar) | [Issues](https://github.com/rs.test/foobar/issues)

This is a test package.
